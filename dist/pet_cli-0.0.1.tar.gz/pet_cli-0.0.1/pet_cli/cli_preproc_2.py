"""
Preprocessing command line interface
"""
import os
import argparse
from pathlib import Path
from pet_cli import image_operations_4d


def generate_args():
    """
    Generates command line arguments for method :main:
    """
    parser = argparse.ArgumentParser(
        prog='PET Preprocessing',
        description='Command line interface for running PET preprocessing steps.',
        epilog=''
    )
    io_grp = parser.add_argument_group('I/O')
    io_grp.add_argument('--pet',required=True,help='Path to PET series')
    io_grp.add_argument('--anatomical',required=False,help='Path to 3D anatomical image')
    io_grp.add_argument('--segmentation',required=False,help='Path to segmentation image\
        in anatomical space')
    io_grp.add_argument('--pet_reference',required=False,help='Path to reference image\
        for motion correction, if not weighted_sum.')
    io_grp.add_argument('--color_table_path',required=False,help='Path to color table')
    io_grp.add_argument('--half_life',required=False,help='Half life of radioisotope in seconds.',
        type=float)
    io_grp.add_argument('--out_dir',required=True,help='Directory to write results to')
    io_grp.add_argument('--subject_id',required=False,help='Subject ID to name files with',
        default='sub')

    ops_grp = parser.add_argument_group('Operations')
    ops_grp.add_argument('--operation',required=True,help='Preprocessing operation to perform',
        choices=['weighted_sum','motion_correct','register','write_tacs'])

    verb_group = parser.add_argument_group('Additional information')
    verb_group.add_argument('-v', '--verbose', action='store_true',
        help='Print processing information during computation.', required=False)

    args = parser.parse_args()
    return args


def create_dirs(main_dir,ops_dir,sub_id,ops_ext):
    """
    Make intermediate directories
    """
    inter_dir = os.path.join(main_dir,ops_dir)
    os.makedirs(inter_dir,exist_ok=True)
    image_write = os.path.join(main_dir,ops_dir,f'{sub_id}_{ops_ext}.nii.gz')
    return image_write


def check_ref(args):
    """
    Check if pet_reference is being used and set variable
    """
    if args.pet_reference is not None:
        ref_image = args.pet_reference
    else:
        ref_image = create_dirs(args.out_dir,'sum_image',args.subject_id,'sum')
    return ref_image


def main():
    """
    Preprocessing command line interface
    """
    args = generate_args()

    if args.operation == 'weighted_sum':
        image_write = create_dirs(args.out_dir,'sum_image',args.subject_id,'sum')
        image_operations_4d.weighted_series_sum(
            input_image_4d_path=args.pet,
            out_image_path=image_write,
            half_life=args.half_life,
            verbose=args.verbose
        )


    if args.operation == 'motion_correct':
        image_write = create_dirs(args.out_dir,'motion-correction',args.subject_id,'moco')
        ref_image = check_ref(args)
        image_operations_4d.motion_correction(
            input_image_4d_path=args.pet,
            reference_image_path=ref_image,
            out_image_path=image_write,
            verbose=args.verbose
        )


    if args.operation == 'register':
        image_write = create_dirs(args.out_dir,'registration',args.subject_id,'reg')
        ref_image = check_ref(args)
        image_operations_4d.register_pet(
            input_calc_image_path=ref_image,
            input_reg_image_path=args.pet,
            reference_image_path=args.anatomical,
            out_image_path=image_write,
            verbose=args.verbose
        )


    if args.operation == 'write_tacs':
        tac_write = os.path.join(args.out_dir,'tacs')
        os.makedirs(tac_write)
        image_write = create_dirs(args.out_dir,'segmentation',args.subject_id,'seg')
        image_operations_4d.resample_segmentation(
            input_image_4d_path=args.pet,
            segmentation_image_path=args.segmentation,
            out_seg_path=image_write,
            verbose=args.verbose
        )
        image_operations_4d.write_tacs(
            input_image_4d_path=args.pet,
            color_table_path=args.color_table_path,
            segmentation_image_path=image_write,
            out_tac_path=tac_write,
            verbose=args.verbose
        )


if __name__ == "__main__":
    main()
